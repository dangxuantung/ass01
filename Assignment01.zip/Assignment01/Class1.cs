﻿namespace Assignment01
{
    public class Class1
    {

    }
}